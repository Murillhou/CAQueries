package com.clarkparsia.pellet.rules.rete;

public class RetePrinter {
	public void print(AlphaNetwork network) {
		for (AlphaNode node : network) {
	        
        }
	}
}
